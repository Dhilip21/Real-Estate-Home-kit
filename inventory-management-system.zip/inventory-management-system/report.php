<?php require_once 'includes/header.php'; ?>

<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<i class="glyphicon glyphicon-check"></i>	Order Report
			</div>
			<!-- /panel-heading -->
			<div class="panel-body">
				
				<form class="form-horizontal" action="php_action/getOrderReport.php" method="post" id="getOrderReportForm">
				  
				  
				<div class="form-group">
				  <label for="category" class="col-sm-2 control-label">Category</label>
				  <div class="col-sm-10">
				  <select class="form-control" name="categoryID" >
			  						<option value="">~~SELECT~~</option>
			  						<?php
			  							$categorySql = "SELECT * FROM categories WHERE categories_active = 1 AND categories_status = 1";
			  							$categoryData = $connect->query($categorySql);

			  							while($row = $categoryData->fetch_array()) {									 		
			  								echo "<option value='".$row['categories_id']."' id='changeProduct".$row['categories_id']."'>".$row['categories_name']."</option>";
										 	} // /while 

			  						?>
		  						</select>
                    </div>
				</div>

				  <div class="form-group">
				    <div class="col-sm-offset-2 col-sm-10">
				      <button type="submit" class="btn btn-success" id="generateReportBtn"> <i class="glyphicon glyphicon-ok-sign"></i> Generate Report</button>
				    </div>
				  </div>
				</form>

			</div>
			<!-- /panel-body -->
		</div>
	</div>
	<!-- /col-dm-12 -->
</div>
<!-- /row -->

<script src="custom/js/report.js"></script>

<?php require_once 'includes/footer.php'; ?>