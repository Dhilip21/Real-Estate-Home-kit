<?php 

require_once 'core.php';

if($_POST) {

	$category_wise=$_POST['categoryID'];
	
	$sql="SELECT * FROM categories 
		  LEFT JOIN product on categories.categories_id=product.categories_id 
		  LEFT JOIN order_item on order_item.product_id=product.product_id
		  WHERE product.categories_id='$category_wise'";
	
	$query = $connect->query($sql);

	$table = '
	<table border="1" cellspacing="0" cellpadding="0" style="width:100%;">
		<tr>
			<th>Product Name</th>
			<th>Category Name</th>
					
			<th>Rate</th>
			<th>Quantity</th>	
			<th>Grand Total</th>
		</tr>

		<tr>';
		$totalAmount = 0;
		while ($result = $query->fetch_assoc()) {
			$table .= '<tr>
				<td><center>'.$result['product_name'].'</center></td>
				<td><center>'.$result['categories_name'].'</center></td>
							
				<td><center>'.$result['rate'].'</center></td>
						<td><center>'.$result['quantity'].'</center></td>		
				<td><center>'.$result['total'].'</center></td>
						
			</tr>';	
			$totalAmount += $result['total'];
		}
		$table .= '
		</tr>

		<tr>
			<td colspan="4"><center>Total Sales Revenue</center></td>
			<td><center>'.$totalAmount.'</center></td>
		</tr>
	</table>
	';	

	echo $table;

	?> <h2>Stocks Remaining</h2> <?php

	$pdt ="SELECT * FROM product  WHERE product.categories_id='$category_wise'";
	$remainingstck = $connect->query($pdt);

	$stocktable = '
	<table border="1" cellspacing="0" cellpadding="0" style="width:100%;">
		<tr>
			<th>Products Name</th>
			<th>Number of Stocks Left</th>
		</tr>

		<tr>';
		while ($products = $remainingstck->fetch_array()) {
			$stocktable .= '<tr>
				<td><center>'.$products['product_name'].'</center></td>
				<td><center>'.$products['quantity'].'</center></td>
			</tr>';	
		}
		$stocktable .= '
		</tr>
   </table>
	';	

	echo $stocktable;

}

?>