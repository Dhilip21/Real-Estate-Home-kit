<?php    

require_once 'core.php';

function AmountInWords(float $amount)
{
	$amount_after_decimal = round($amount - ($num = floor($amount)), 2) * 100;
	// Check if there is any number after decimal
	$amt_hundred = null;
	$count_length = strlen($num);
	$x = 0;
	$string = array();
	$change_words = array(0 => '', 1 => 'One', 2 => 'Two',
			3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six',
			7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
			10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',
			13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
			16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
			19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
			40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty',
			70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
	$here_digits = array('', 'Hundred','Thousand','Lakh', 'Crore');
	while( $x < $count_length ) {
		$get_divider = ($x == 2) ? 10 : 100;
		$amount = floor($num % $get_divider);
		$num = floor($num / $get_divider);
		$x += $get_divider == 10 ? 1 : 2;
		if ($amount) {
			$add_plural = (($counter = count($string)) && $amount > 9) ? 's' : null;
			$amt_hundred = ($counter == 1 && $string[0]) ? ' and ' : null;
			$string [] = ($amount < 21) ? $change_words[$amount].' '. $here_digits[$counter]. $add_plural.'
       '.$amt_hundred:$change_words[floor($amount / 10) * 10].' '.$change_words[$amount % 10]. '
       '.$here_digits[$counter].$add_plural.' '.$amt_hundred;
		}
		else $string[] = null;
	}
	$implode_to_Rupees = implode('', array_reverse($string));
	$get_paise = ($amount_after_decimal > 0) ? "And " . ($change_words[$amount_after_decimal / 10] . "
   " . $change_words[$amount_after_decimal % 10]) . ' Paise' : '';
	return ($implode_to_Rupees ? $implode_to_Rupees . 'Rupees ' : '') . $get_paise;
}


$orderId = $_POST['orderId'];

$sql = "SELECT order_date, client_name, client_contact, sub_total, vat, total_amount, discount, grand_total, paid, due,order_id FROM orders WHERE order_id = $orderId";

$orderResult = $connect->query($sql);
$orderData = $orderResult->fetch_array();

$orderDate = $orderData[0];
$clientName = $orderData[1];
$clientContact = $orderData[2]; 
$subTotal = $orderData[3];
$vat = $orderData[4];
$totalAmount = $orderData[5]; 
$discount = $orderData[6];
$grandTotal = $orderData[7];
$paid = $orderData[8];
$due = $orderData[9];
$billNo=$orderData[10];
$amtInWords=AmountInWords($grandTotal);

//$payment_place = $orderData[10];
//$gstn = $orderData[11];


$orderItemSql = "SELECT order_item.product_id, order_item.rate, order_item.quantity, order_item.total,
product.product_name FROM order_item
   INNER JOIN product ON order_item.product_id = product.product_id 
 WHERE order_item.order_id = $orderId";
$orderItemResult = $connect->query($orderItemSql);

 $table = '<style>
.star img {
    visibility: visible;
}</style>
<table align="center" cellpadding="0" cellspacing="0" style="width: 100%;border:1px solid black;margin-bottom: 10px;">
               <tbody>
                  <tr>
                     <td colspan="5" style="text-align:center;color: black;text-decoration: underline;font-size: 25px;">TAX INVOICE</td>
                  </tr>
                  <tr>
                     <td colspan="3" style="border-left:30px solid white; align:"center"; " background-image="logo.jpeg"><img src="\assests\images\logo.jpeg" alt="logo" width="115px;"></td>
                     <td colspan="3" style=" text-align: right;">DUPLICATE</td>
                  </tr>
                  <tr>
                     <td colspan="5" style="text-align: center;color:black;font-weight: 600;text-decoration: underline;font-size: 25px;">MAYUR COMPANY OUTLET</td> 
				  </tr>
				  <tr>
					<td colspan="5" style="text-align: center;color:black;font-style: italic;font-weight: 500;font-size: 20px;">Rishabh Collection</td>
                  </tr>
				  <tr>
                     <td colspan="5" style=" text-align: right; align: right;">0, Mayur Company Outlet</td>
                  </tr>
                  <tr>
                     <td colspan="5" style=" text-align: right;">Near mill gate of RSWM Ltd</td>
                  </tr>
				  <tr>
                     <td colspan="5" style=" text-align: right;">Mandapam Bhilwara</td>
                  </tr>
                  <tr>
                     <td  colspan="5" style=" text-align: right;">Tele:</td>
                  </tr>
                  <tr>
                     <td colspan="5" style=" text-align: right;">GST No.: 08ACAPW1226G1ZR</td>
                  </tr>
                  
                  <tr>
                     <td colspan="2" style="padding: 0px;vertical-align: top;border-right:1px solid black;">
                        <table align="left" cellpadding="0" cellspacing="0" style="border: thin solid black; width: 100%">
                           <tbody>
                              <tr>
                                 <td style="width: 74px;vertical-align: top;color: black;" rowspan="3">TO, </td>
                                 <td style="border-bottom-style: solid; border-bottom-width: thin; border-bottom-color: black">&nbsp;'.$clientName.'</td>
                              </tr>
                              <tr>
                                 <td style="border-bottom-style: solid; border-bottom-width: thin; border-bottom-color: black">&nbsp;</td>
                              </tr>
                              <tr>
                                 <td style="border-bottom-style: solid; border-bottom-width: thin; border-bottom-color: black">&nbsp;</td>
                              </tr>
                           </tbody>
                        </table>
                        <table align="left" cellspacing="0" style="width: 100%; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-right-width: thin; border-bottom-width: thin; border-left-width: thin; border-right-color: black; border-bottom-color: black; border-left-color: black;">
                           <tbody>
                              <tr>
                                 <td style="border-left-style: solid; border-left-width: thin; border-left-color: black; border-bottom-style: solid; border-bottom-width: thin; border-bottom-color: black;color: black;">Mobile No: '.$clientContact.'</td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                     <td style="padding: 0px;vertical-align: top;" colspan="3">
                        <table align="left" cellpadding="0" cellspacing="0" style="width: 100%">
                           <tbody>
                              <tr>
                                 <td style="border-bottom-style: solid;border-bottom-width: thin;border-bottom-color: black;border-top: 1px solid black;border-right: 1px solid black;color: black;">Bill No :'.$billNo.' </td>
                              </tr>
                              <tr>
                                 <td style="border-bottom-style: solid;border-bottom-width: thin;border-bottom-color: black;border-right: 1px solid black;    color: black;">Date: '.$orderDate.'</td>
                              </tr>
					</tbody>
                        </table>
                     </td>
                  </tr>
                  <tr>
                     <td style="width: 123px;text-align: center;background-color: black;color: white;border-right: 1px solid white;border-left: 1px solid black;border-bottom: 1px solid black;-webkit-print-color-adjust: exact;">D.C.NO<br>
                        &amp;DATE
                     </td>
                     <td style="width: 50%;text-align: center;border-top-style: solid;border-right-style: solid;border-bottom-style: solid;border-top-width: thin;border-right-width: thin;border-bottom-width: thin;border-top-color: black;border-right-color: white;border-bottom-color: black;color: white;background-color: black;-webkit-print-color-adjust: exact;">Description Of Goods</td>
                     <td style="width: 150px;text-align: center;border-top-style: solid;border-right-style: solid;border-bottom-style: solid;border-top-width: thin;border-right-width: thin;border-bottom-width: thin;border-top-color: black;border-right-color: #fff;border-bottom-color: black;background-color: black;color: white;-webkit-print-color-adjust: exact;">Qty.</td>
                     <td style="width: 150px;text-align: center;border-top-style: solid;border-right-style: solid;border-bottom-style: solid;border-top-width: thin;border-right-width: thin;border-bottom-width: thin;border-top-color: black;border-right-color: #fff;border-bottom-color: black;background-color: black;color: white;-webkit-print-color-adjust: exact;">Rate&nbsp; Rs.<br>
                        Ps
                     </td>
                     <td style="width: 150px;text-align: center;border-top-style: solid;border-right-style: solid;border-bottom-style: solid;border-top-width: thin;border-right-width: thin;border-bottom-width: thin;border-top-color: black;border-right-color: black;border-bottom-color: black;color: white;background-color: black;-webkit-print-color-adjust: exact;">Amount&nbsp; Rs.<br>
                        &nbsp;Ps
                     </td>
                  </tr>';
                  $x = 1;
                 // $cgst = 0;
                  //$igst = 0;
                 /*  if($payment_place == 2)
                  {
                     $igst = $subTotal*18/100;
                  }
                  else
                  {
                     $cgst = $subTotal*9/100;
                  } */
                 // $total = $subTotal+2*$cgst+$igst;
                  $total = $subTotal;
            while($row = $orderItemResult->fetch_array()) {       
                        
               $table .= '<tr>
                     <td style="border-left: 1px solid black;border-right: 1px solid black;height: 27px;">'.$x.'</td>
                     <td style="border-left: 1px solid black;height: 27px;">'.$row[4].'</td>
                     <td style="border-left: 1px solid black;height: 27px;">'.$row[2].'</td>
                     <td style="border-left: 1px solid black;height: 27px;">'.$row[1].'</td>
                     <td style="border-left: 1px solid black;border-right: 1px solid black;height: 27px;">'.$row[3].'</td>
                  </tr>
               ';
            $x++;
            } // /while
                $table.= '
                  <tr style="border-bottom: 1px solid black;">
                     <td style="border-left: 1px solid black;border-right: 1px solid black;height: 27px;"></td>
                     <td style="border-left: 1px solid black;height: 27px;"></td>
                     <td style="border-left: 1px solid black;height: 27px;"></td>
                     <td style="width: 149px;border-right-style: solid;border-bottom-style: solid;border-right-width: thin;border-bottom-width: thin;border-right-color: black;border-bottom-color: #000;background-color: black;color: white;padding-left: 5px;-webkit-print-color-adjust: exact;">Total</td>
                     <td style="width: 218px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-top-width: thin; border-right-width: thin; border-bottom-width: thin; border-top-color: black; border-right-color: black; border-bottom-color: black;">'.$subTotal.'</td>
                     		
                  </tr>
 <tr>
                     <td colspan="3" style="border-left: 1px solid black;border-bottom: 1px solid black;color: black;padding: 5px;"></td>
                     		                    <td style="width: 149px;border-right-style: solid;border-bottom-style: solid;border-right-width: thin;border-bottom-width: thin;border-right-color: black;border-bottom-color: #000;background-color: black;color: white;padding-left: 5px;-webkit-print-color-adjust: exact;">Discount</td>
                     <td style="width: 218px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-top-width: thin; border-right-width: thin; border-bottom-width: thin; border-top-color: black; border-right-color: black; border-bottom-color: black;">'.$discount.'%</td> 		
                     	</tr>	
				  <tr>
                     <td colspan="3" style="border-left: 1px solid black;border-bottom: 1px solid black;color: black;padding: 5px;">Amount in words : '.$amtInWords.'</td>
                     <td style="border-bottom: 1px solid #fff;background-color: black;color: white;padding: 5px;-webkit-print-color-adjust: exact;">G. Total</td>
                     <td style="border-bottom: 1px solid black;border-right: 1px solid;">'.$grandTotal.'</td>
                  </tr>
                  
				  <tr>
                     <td colspan="3" style="border-left: 1px solid black;border-bottom: 1px solid black;padding: 5px;border-right: 1px solid black;">UNDER COMPOSTION SCHEME
					 <span style="float: center;  font-size: 9px;">Composition taxable person not eligible to collect tax on supplies</span></td>
					 <td rowspan="2" colspan="2" style="vertical-align: bottom;padding: 5px;color: black;border-bottom: 1px solid black;text-align: center;">Authorized Signatory</td>
                  </tr>
                  
				  
				  <tr>
                     <td colspan="3" style="border-left: 1px solid black;padding-left: 5px;border-right: 1px solid black; font-size: 15px;">
                        Wash care instruction for:</td>
				  </tr>
				  <tr>
					<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							1	Use mild detergent for washing</td>
				  </tr>
				  <tr>
							<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							2	Reverse garments while washing</td>
				  </tr>
				  <tr>
							<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							3	Dry garments in shade</td>
				  </tr>	
				  <tr>
							<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							4	Use cold water for wash</td>
				  </tr>
				  <tr>
							<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							5	Do not twist and squeeze dry</td>
				  </tr>
				  <tr>
							<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							6	Do not use very hot iron</td>
				  </tr>
				  <tr>
							<td colspan="3" style="border-left: 1px solid black;padding-left: 3px;border-right: 1px solid black; font-size: 12px;">
							7	Please ensure above for endurance and long life of our garments/fabrics
                     </td>
				  </tr>
               </tbody>
            </table>';
$connect->close();

echo $table;